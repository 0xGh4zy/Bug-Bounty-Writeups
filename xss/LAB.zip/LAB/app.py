from flask import Flask, render_template, jsonify

app = Flask(__name__)

@app.get('/')
def login():
    # The login page is intentionally fictional. No credentials are accepted or stored.
    return render_template('login.html')

@app.get('/health')
def health():
    return jsonify(status='ok', app='The Forbidden Script local login demo')

if __name__ == '__main__':
    # Localhost only: do not expose this intentionally vulnerable training demo publicly.
    app.run(host='127.0.0.1', port=5000, debug=True)
