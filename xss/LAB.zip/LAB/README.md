# The Forbidden Script — Flask Login Lab

A minimal, fictional login page served by Flask. The visible page stays a login screen; the intentionally vulnerable client-side query processing lives in `static/app.js`. The provided `poc.py` generates an OpenSSL `Salted__` AES-CBC hex URL compatible with the lab's browser-side decryption.

## Run locally

### Windows PowerShell

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

In a second terminal, activate the same environment and install the PoC dependency if needed:

```powershell
python -m pip install pycryptodome
python poc.py
```

Open the printed URL in the same browser where the local app is running. The payload is the harmless training proof `Pwned by 0xgh4zy` and an alert, executed only in a sandboxed iframe on localhost.

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

In another terminal using the same virtual environment:

```bash
python -m pip install pycryptodome
python poc.py
```

Open http://127.0.0.1:5000. Health check: http://127.0.0.1:5000/health

## How the demo works

- `poc.py` encrypts the parameter names and values using AES-256-CBC, an 8-byte random salt, OpenSSL's `Salted__` envelope, and the MD5-based EVP_BytesToKey derivation used by CryptoJS passphrase mode. The resulting bytes are hex encoded.
- `static/app.js` performs the matching decryption in the browser, decodes `msg` and `type`, applies an intentionally incomplete HTML-tag blocklist, then demonstrates the unsafe HTML sink inside a sandboxed iframe.
- The iframe permits scripts and modal dialogs only so the local proof can be observed; it does not permit same-origin access, forms, popups, or network connections. It cannot read the parent page's cookies/storage or send data out.
- The login form never submits or stores credentials. The verification widget is visual-only, not a real Cloudflare challenge.
- The L-inspired background image is included locally at `static/images/l-detective.jpg`; no external images or services are requested.

## Safety

This lab intentionally demonstrates a vulnerable pattern and must remain local. Flask binds to `127.0.0.1`; do not expose it to a public network or deploy it as a real login page. The key is a public demo value and is not a security control.

## Credits

`0xgh4zy` · Youssef Wael
