'use strict';

// Local training demo only. This intentionally mirrors OpenSSL/CryptoJS passphrase
// encryption so the accompanying Python PoC can be used against 127.0.0.1.
const DEMO_KEY = '0xgh4zy-demo-key-never-use-this-in-production';
const BLOCKLIST = /<(script|form|iframe|object|embed|link|style|meta|img|svg|input|button|textarea|select)[^>]*>/i;
const messageBox = document.getElementById('message');
const messageFrame = document.getElementById('message-frame');
const password = document.getElementById('password');
const togglePassword = document.getElementById('toggle-password');
const form = document.getElementById('login-form');
const signIn = document.getElementById('sign-in');

// Small MD5 implementation used only for the demo's OpenSSL EVP_BytesToKey derivation.
function md5(input) {
  const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
  const bitLen = bytes.length * 8;
  const paddedLen = (((bytes.length + 8) >>> 6) + 1) * 64;
  const data = new Uint8Array(paddedLen);
  data.set(bytes); data[bytes.length] = 0x80;
  const view = new DataView(data.buffer);
  view.setUint32(paddedLen - 8, bitLen >>> 0, true);
  view.setUint32(paddedLen - 4, Math.floor(bitLen / 0x100000000), true);
  let a0=0x67452301, b0=0xefcdab89, c0=0x98badcfe, d0=0x10325476;
  const shifts=[7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21];
  const K=Array.from({length:64},(_,i)=>Math.floor(Math.abs(Math.sin(i+1))*0x100000000)>>>0);
  const rot=(x,n)=>(x<<n)|(x>>>(32-n));
  for(let offset=0;offset<data.length;offset+=64){
    const M=Array.from({length:16},(_,i)=>view.getUint32(offset+i*4,true));
    let A=a0,B=b0,C=c0,D=d0;
    for(let i=0;i<64;i++){
      let F,g;
      if(i<16){F=(B&C)|(~B&D);g=i;}
      else if(i<32){F=(D&B)|(~D&C);g=(5*i+1)%16;}
      else if(i<48){F=B^C^D;g=(3*i+5)%16;}
      else{F=C^(B|~D);g=(7*i)%16;}
      const temp=D; D=C; C=B; B=(B+rot((A+F+K[i]+M[g])>>>0,shifts[i]))>>>0; A=temp;
    }
    a0=(a0+A)>>>0;b0=(b0+B)>>>0;c0=(c0+C)>>>0;d0=(d0+D)>>>0;
  }
  const out=new Uint8Array(16), outView=new DataView(out.buffer);
  [a0,b0,c0,d0].forEach((v,i)=>outView.setUint32(i*4,v,true));
  return out;
}
function concatBytes(...arrays){const out=new Uint8Array(arrays.reduce((n,a)=>n+a.length,0));let p=0;for(const a of arrays){out.set(a,p);p+=a.length;}return out;}
function hexToBytes(hex){if(!/^(?:[0-9a-f]{2})+$/i.test(hex))throw new Error('Invalid hex');return Uint8Array.from(hex.match(/.{2}/g),b=>parseInt(b,16));}
function deriveOpenSslKeyIv(passwordBytes,salt){
  let material=new Uint8Array(0), previous=new Uint8Array(0);
  while(material.length<48){previous=md5(concatBytes(previous,passwordBytes,salt));material=concatBytes(material,previous);}
  return {key:material.slice(0,32),iv:material.slice(32,48)};
}
async function decryptDemoValue(hexValue){
  const raw=hexToBytes(hexValue);
  if(raw.length<32 || new TextDecoder().decode(raw.slice(0,8))!=='Salted__')throw new Error('Not OpenSSL salted ciphertext');
  const salt=raw.slice(8,16), ciphertext=raw.slice(16);
  const derived=deriveOpenSslKeyIv(new TextEncoder().encode(DEMO_KEY),salt);
  const key=await crypto.subtle.importKey('raw',derived.key,{name:'AES-CBC'},false,['decrypt']);
  const plaintext=await crypto.subtle.decrypt({name:'AES-CBC',iv:derived.iv},key,ciphertext);
  return new TextDecoder().decode(plaintext);
}
function showMessage(text){
  messageBox.hidden=false;
  // Intentional HTML sink, confined to a sandboxed iframe with no network or parent access.
  const documentText=`<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'none'; img-src data:"><style>body{margin:0;padding:5px 4px;background:#f8dfe4;font:18px Arial,sans-serif;color:#a20d31;text-align:center;overflow-wrap:anywhere}h2{margin:5px 0;font-size:27px;font-weight:400}details{min-height:30px}summary{cursor:pointer;color:#28205f}</style></head><body><div id="message"></div><script>const message=${JSON.stringify(text)};document.getElementById('message').innerHTML=message;document.documentElement.style.height='auto';parent.postMessage({kind:'lab-preview-height',height:Math.min(document.body.scrollHeight+10,260)},'*');<\/script></body></html>`;
  messageFrame.srcdoc=documentText;
  messageFrame.style.height='96px';
}
window.addEventListener('message',event=>{
  if(event.source!==messageFrame.contentWindow || !event.data || event.data.kind!=='lab-preview-height')return;
  messageFrame.style.height=`${Math.max(60,Math.min(Number(event.data.height)||96,260))}px`;
});
async function inspectQuery(){
  const params=[...new URLSearchParams(window.location.search).entries()];
  if(!params.length)return;
  const decoded={};
  for(const [rawName,rawValue] of params){try{decoded[await decryptDemoValue(rawName)]=await decryptDemoValue(rawValue);}catch(_){/* ignore ordinary/malformed query strings */}}
  if(!decoded.msg)return;
  if(BLOCKLIST.test(decoded.msg)){history.replaceState({},'',location.pathname);showMessage('This demo message was rejected by the training blocklist.');return;}
  showMessage(decoded.msg);
}
form.addEventListener('submit',event=>{event.preventDefault();signIn.disabled=true;signIn.textContent='Sign-in disabled in demo';window.setTimeout(()=>{signIn.disabled=false;signIn.innerHTML='Sign in <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m9 18 6-6-6-6"/></svg>';showMessage('Demo only — sign-in is disabled. No credentials were sent or stored.');},350);});
togglePassword.addEventListener('click',()=>{const reveal=password.type==='password';password.type=reveal?'text':'password';togglePassword.setAttribute('aria-label',reveal?'Hide password':'Show password');});
document.getElementById('forgot').addEventListener('click',()=>showMessage('Password recovery is disabled in this local training demo.'));
void inspectQuery();
